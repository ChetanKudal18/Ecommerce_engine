let sortby_btn = document.getElementById('sortby_btn');
let sortby_opt = document.getElementsByClassName('sortby_opt')[0];

sortby_btn.addEventListener('click', () => {
  sortby_opt.classList.toggle('sortby_opt_active');
});

let newest = document.getElementById('newest');
let all_shoes = document.getElementById('all_shoes');
let low = document.getElementById('low');
let high = document.getElementById('high');

let jsonData = [
  {
    "id": 1,
    "Name": "Nike Air Force 1 Mid QS",
    "Category": "Men's",
    "Color": 1,
    "Price": 2599,
    "MRP": 6999,
    "Tag": "Sustainable Materials",
    "Size6": 6,
    "Size7": 7,
    "Size8": 8,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Force 1 Mid QS.webp",
    "Type": "Air Force",
    "ColorTag": "green"
  },
  {
    "id": 2,
    "Name": "Nike Air Force 1 Mid React",
    "Category": "Men's",
    "Color": 3,
    "Price": 11956,
    "MRP": 22569,
    "Tag": "",
    "Size6": 6,
    "Size7": 0,
    "Size8": 8,
    "Size9": 0,
    "Size10": 10,
    "Size11.5": 0,
    "Img": "img/Nike Air Force 1 Mid React.webp",
    "Type": "Air Force",
    "ColorTag": "white"
},
{
    "id": 3,
    "Name": "Nike Air Force 1'07 LV8",
    "Category": "Men's",
    "Color": 2,
    "Price": 8556,
    "MRP": 12857,
    "Tag": "Promo Exclusion",
    "Size6": 0,
    "Size7": 7,
    "Size8": 8,
    "Size9": 9,
    "Size10": 0,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Force 1'07 LV8.webp",
    "Type": "Air Force",
    "ColorTag": "black"
},
{
    "id": 4,
    "Name": "Nike Air Max 90 GTX",
    "Category": "Men's",
    "Color": 3,
    "Price": 15423,
    "MRP": 20854,
    "Tag": "",
    "Size4": 4,
    "Size6": 6,
    "Size7": 7,
    "Size8": 0,
    "Size9": 0,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Max 90 GTX.webp",
    "Type": "Air Max",
    "ColorTag": "gary-black"
},
{
    "id": 5,
    "Name": "Nike Air Max 90 SE",
    "Category": "Men's",
    "Color": 1,
    "Price": 12723,
    "MRP": 15953,
    "Tag": "In Just",
    "Size6": 0,
    "Size7": 7,
    "Size8": 0,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Max 90 SE.webp",
    "Type": "Air Max",
    "ColorTag": "white"
},
{
    "id": 6,
    "Name": "Nike Air Max 95 SE",
    "Category": "Men's",
    "Color": 2,
    "Price": 18723,
    "MRP": 2953,
    "Tag": "",
    "Size6": 6,
    "Size7": 7,
    "Size8": 8,
    "Size9": 0,
    "Size10": 0,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Max 95 SE.webp",
    "Type": "Air Max",
    "ColorTag": "red"
},
{
    "id": 7,
    "Name": "Nike Air Max 97 SE",
    "Category": "Men's",
    "Color": 1,
    "Price": 7723,
    "MRP": 9253,
    "Tag": "In Just",
    "Size6": 6,
    "Size7": 0,
    "Size8": 8,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 0,
    "Img": "img/Nike Air Max 97 SE.jpg",
    "Type": "Air Max",
    "ColorTag": "gary-white"
},
{
    "id": 8,
    "Name": "Nike Air Max 97 SE 2",
    "Category": "Men's",
    "Color": 2,
    "Price": 6323,
    "MRP": 9274,
    "Tag": "",
    "Size6": 6,
    "Size7": 0,
    "Size8": 8,
    "Size9": 0,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Max 97 SE.webp",
    "Type": "Air Max",
    "ColorTag": "yellow"
},
{
    "id": 9,
    "Name": "Nike Air Max 270",
    "Category": "Men's",
    "Color": 3,
    "Price": 9323,
    "MRP": 12274,
    "Tag": "Sustainable Materials",
    "Size6": 0,
    "Size7": 0,
    "Size8": 8,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Max 270.webp",
    "Type": "Air Max",
    "ColorTag": "sky-blue"
},
{
    "id": 10,
    "Name": "Nike Air Max Flyknit Racer",
    "Category": "Men's",
    "Color": 2,
    "Price": 48323,
    "MRP": 52274,
    "Tag": "",
    "Size6": 6,
    "Size7": 7,
    "Size8": 8,
    "Size9": 0,
    "Size10": 10,
    "Size11.5": 0,
    "Img": "img/Nike Air Max Flyknit Racer.webp",
    "Type": "Air Max",
    "ColorTag": "black"
},
{
    "id": 11,
    "Name": "Nike Air Max TW",
    "Category": "Men's",
    "Color": 1,
    "Price": 23323,
    "MRP": 28274,
    "Tag": "Promo Exclusion",
    "Size6": 0,
    "Size7": 7,
    "Size8": 0,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Max TW.webp",
    "Type": "Air Max",
    "ColorTag": "red"
},
{
    "id": 12,
    "Name": "Nike Air More Uptempo '96",
    "Category": "Men's",
    "Color": 3,
    "Price": 78451,
    "MRP": 98456,
    "Tag": "",
    "Size6": 6,
    "Size7": 0,
    "Size8": 8,
    "Size9": 0,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Air More Uptempo '96.webp",
    "Type": "Nike Dunk",
    "ColorTag": "sky-blue"
},
{
    "id": 13,
    "Name": "Nike Air Pegasus 83 Premium",
    "Category": "Men's",
    "Color": 2,
    "Price": 56451,
    "MRP": 73456,
    "Tag": "In Just",
    "Size6": 6,
    "Size7": 7,
    "Size8": 8,
    "Size9": 9,
    "Size10": 0,
    "Size11.5": 0,
    "Img": "img/Nike Air Pegasus 83 Premium.webp",
    "Type": "Pegasus",
    "ColorTag": "gary-white"
},
{
    "id": 14,
    "Name": "Nike Air Zoom Pegasus 39 Shield",
    "Category": "Men's",
    "Color": 1,
    "Price": 24451,
    "MRP": 29456,
    "Tag": "",
    "Size6": 6,
    "Size7": 0,
    "Size8": 8,
    "Size9": 9,
    "Size10": 0,
    "Size11.5": 11.5,
    "Img": "img/Nike Air Zoom Pegasus 39 Shield.webp",
    "Type": "Zoom Rival",
    "ColorTag": "black"
},
{
    "id": 15,
    "Name": "Nike Blazer Low '77 Jumbo",
    "Category": "Men's",
    "Color": 2,
    "Price": 12451,
    "MRP": 18456,
    "Tag": "",
    "Size6": 0,
    "Size7": 0,
    "Size8": 8,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Blazer Low '77 Jumbo.webp",
    "Type": "Loafer",
    "ColorTag": "white"
},
{
    "id": 16,
    "Name": "Nike Blazer Mid '77 Premium",
    "Category": "Men's",
    "Color": 3,
    "Price": 45451,
    "MRP": 69456,
    "Tag": "",
    "Size6": 6,
    "Size7": 0,
    "Size8": 8,
    "Size9": 0,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Blazer Mid '77 Premium.webp",
    "Type": "Loafer",
    "ColorTag": "brown"
},
{
    "id": 17,
    "Name": "Nike Invincible Run 2",
    "Category": "Men's",
    "Color": 2,
    "Price": 14451,
    "MRP": 18456,
    "Tag": "In Just",
    "Size6": 6,
    "Size7": 7,
    "Size8": 8,
    "Size9": 0,
    "Size10": 0,
    "Size11.5": 11.5,
    "Img": "img/Nike Invincible Run 2.webp",
    "Type": "Boots",
    "ColorTag": "black"
},
{
    "id": 18,
    "Name": "Nike Dunk 8",
    "Category": "Men's",
    "Color": 2,
    "Price": 19451,
    "MRP": 25456,
    "Tag": "",
    "Size6": 6,
    "Size7": 0,
    "Size8": 8,
    "Size9": 9,
    "Size10": 0,
    "Size11.5": 11.5,
    "Img": "img/Nike Metcon 8.webp",
    "Type": "Nike Dunk",
    "ColorTag": "green"
},
{
    "id": 19,
    "Name": "Nike Pegasus 39",
    "Category": "Men's",
    "Color": 3,
    "Price": 28451,
    "MRP": 36456,
    "Tag": "",
    "Size6": 6,
    "Size7": 7,
    "Size8": 0,
    "Size9": 0,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Pegasus 39.webp",
    "Type": "Pegasus",
    "ColorTag": "orange"
},
{
    "id": 20,
    "Name": "Nike React Infinity Run Flyknit 3",
    "Category": "Men's",
    "Color": 1,
    "Price": 45451,
    "MRP": 52456,
    "Tag": "Sustainable Materials",
    "Size6": 0,
    "Size7": 7,
    "Size8": 0,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike React Infinity Run Flyknit 3.webp",
    "Type": "Boots",
    "ColorTag": "white"
},
{
    "id": 21,
    "Name": "Nike Waffle Debut",
    "Category": "Men's",
    "Color": 1,
    "Price": 15000,
    "MRP": 18000,
    "Tag": "Sustainable Materials",
    "Size6": 6,
    "Size7": 7,
    "Size8": 0,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Waffle Debut.webp",
    "Type": "Boots",
    "ColorTag": "green"
},
{
    "id": 22,
    "Name": "Nike Zoom Fly 5",
    "Category": "Men's",
    "Color": 1,
    "Price": 30000,
    "MRP": 35000,
    "Tag": "Sustainable Materials",
    "Size6": 6,
    "Size7": 7,
    "Size8": 8,
    "Size9": 9,
    "Size10": 10,
    "Size11.5": 11.5,
    "Img": "img/Nike Zoom Fly 5.jpg",
    "Type": "Boots",
    "ColorTag": "orange"
}
];

let main_shoes_bx = document.getElementsByClassName('main_shoes_bx')[0];

let all_shoes_array = [];
let low_array = [];
let high_array = [];
let newest_array = [];

function fetchData() {
  all_shoes_array = [...jsonData];
  low_array = [...jsonData];
  high_array = [...jsonData];
  newest_array = [...jsonData].splice(0, 8);

  renderShoes(all_shoes_array);
}

function renderShoes(shoesArray) {
  main_shoes_bx.innerHTML = '';
  shoesArray.forEach((el, i) => {
    const { Img, Name, Category, MRP, Price, Tag, Color } = el;
    let card = document.createElement('a');
    card.classList.add('card');
    card.innerHTML = `
      <img src="${Img}" alt="${Name}" />
      <h5 class="card_title" title="${Name}">${Name}</h5>
      <p>${Category} Shoes</p>
      <div class="price">
        <h5>Rs ${Price}</h5>
        <h5>MRP: <del>RS ${MRP}</del></h5>
      </div>
      <div class="color_tag">
        <h6>Color ${Color}</h6>
        <h6>${Tag}</h6>
      </div>
    `;
    main_shoes_bx.appendChild(card);
  });
}

fetchData();

newest.addEventListener('click', () => {
  sortby_btn.innerHTML = `<h5>Sort By: Newest</h5><i class="bi bi-chevron-down"></i>`;
  sortby_opt.classList.toggle('sortby_opt_active');
  renderShoes(newest_array);
});

all_shoes.addEventListener('click', () => {
  sortby_btn.innerHTML = `<h5>Sort By: All Shoes</h5><i class="bi bi-chevron-down"></i>`;
  sortby_opt.classList.toggle('sortby_opt_active');
  renderShoes(all_shoes_array);
});

low.addEventListener('click', () => {
  sortby_btn.innerHTML = `<h5>Sort By: Low</h5><i class="bi bi-chevron-down"></i>`;
  sortby_opt.classList.toggle('sortby_opt_active');
  low_array.sort(({ Price: a }, { Price: b }) => a - b);
  renderShoes(low_array);
});

high.addEventListener('click', () => {
  sortby_btn.innerHTML = `<h5>Sort By: High</h5><i class="bi bi-chevron-down"></i>`;
  sortby_opt.classList.toggle('sortby_opt_active');
  high_array.sort(({ Price: a }, { Price: b }) => a - b);
  high_array.reverse();
  renderShoes(high_array);
});




    let boot_array = all_shoes_array.filter((el)=> {
        return el.Type === 'Boots';
    })

    let All_Main_filter_array = [];

    let boots = document.getElementById('boots');

    boots.addEventListener('click', ()=> {
        if (boots.title === "boots_filter_on") {
            main_shoes_bx.innerHTML = '';
            boots.classList.toggle('i_active');
            boots.classList.toggle('bi-toggle2-off');
            boots.classList.toggle('bi-toggle2-on');
            boots.title = 'boots_filter_off';
            All_Main_filter_array = All_Main_filter_array.concat(boot_array);

            All_Main_filter_array.forEach((el, i) => {
                const {Img,Name,Category, MRP, Price,Tag, Color} = el;
                let card = document.createElement('a');
                card.classList.add('card');
                card.innerHTML = `
                <img src="${Img}" alt="${Name}" />
                <h5 class="card_title" title="${Name}">
                ${Name}
                </h5>
                <p>${Category} Shoes</p>
                <div class="price">
                  <h5>Rs ${Price}</h5>
                  <h5>MRP: <del>RS ${MRP}</del></h5>
                </div>
                <div class="color_tag">
                  <h6>Color ${Color}</h6>
                  <h6>${Tag}</h6>
                </div>
                `;
         main_shoes_bx.appendChild(card)
            });
        } else {
            main_shoes_bx.innerHTML = '';
            boots.classList.toggle('i_active');
            boots.classList.toggle('bi-toggle2-off');
            boots.classList.toggle('bi-toggle2-on');
            boots.title = 'boots_filter_on';
            All_Main_filter_array = All_Main_filter_array.filter((el)=> {
                return boot_array.indexOf(el) < 0;
            })
            All_Main_filter_array.forEach((el, i) => {
                const {Img,Name,Category, MRP, Price,Tag, Color} = el;
                let card = document.createElement('a');
                card.classList.add('card');
                card.innerHTML = `
                <img src="${Img}" alt="${Name}" />
                <h5 class="card_title" title="${Name}">
                ${Name}
                </h5>
                <p>${Category} Shoes</p>
                <div class="price">
                  <h5>Rs ${Price}</h5>
                  <h5>MRP: <del>RS ${MRP}</del></h5>
                </div>
                <div class="color_tag">
                  <h6>Color ${Color}</h6>
                  <h6>${Tag}</h6>
                </div>
                `;
         main_shoes_bx.appendChild(card)
            });
        }
    })

    // Loafer shoes 

    let loafers_array = all_shoes_array.filter((el)=> {
        return el.Type === 'Loafer';
    })


    let loafers = document.getElementById('loafers');

    loafers.addEventListener('click', ()=> {
        if (loafers.title === "loafers_filter_on") {
            main_shoes_bx.innerHTML = '';
            loafers.classList.toggle('i_active');
            loafers.classList.toggle('bi-toggle2-off');
            loafers.classList.toggle('bi-toggle2-on');
            loafers.title = 'loafers_filter_off';
            All_Main_filter_array = All_Main_filter_array.concat(loafers_array);

            All_Main_filter_array.forEach((el, i) => {
                const {Img,Name,Category, MRP, Price,Tag, Color} = el;
                let card = document.createElement('a');
                card.classList.add('card');
                card.innerHTML = `
                <img src="${Img}" alt="${Name}" />
                <h5 class="card_title" title="${Name}">
                ${Name}
                </h5>
                <p>${Category} Shoes</p>
                <div class="price">
                  <h5>Rs ${Price}</h5>
                  <h5>MRP: <del>RS ${MRP}</del></h5>
                </div>
                <div class="color_tag">
                  <h6>Color ${Color}</h6>
                  <h6>${Tag}</h6>
                </div>
                `;
         main_shoes_bx.appendChild(card)
            });
        } else {
            main_shoes_bx.innerHTML = '';
            loafers.classList.toggle('i_active');
            loafers.classList.toggle('bi-toggle2-off');
            loafers.classList.toggle('bi-toggle2-on');
            loafers.title = 'loafers_filter_on';
            All_Main_filter_array = All_Main_filter_array.filter((el)=> {
                return loafers_array.indexOf(el) < 0;
            })
            All_Main_filter_array.forEach((el, i) => {
                const {Img,Name,Category, MRP, Price,Tag, Color} = el;
                let card = document.createElement('a');
                card.classList.add('card');
                card.innerHTML = `
                <img src="${Img}" alt="${Name}" />
                <h5 class="card_title" title="${Name}">
                ${Name}
                </h5>
                <p>${Category} Shoes</p>
                <div class="price">
                  <h5>Rs ${Price}</h5>
                  <h5>MRP: <del>RS ${MRP}</del></h5>
                </div>
                <div class="color_tag">
                  <h6>Color ${Color}</h6>
                  <h6>${Tag}</h6>
                </div>
                `;
         main_shoes_bx.appendChild(card)
            });
        }
    })
    let right_input = document.getElementById('right_input');
let left_input = document.getElementById('left_input');
let left_input_icon = document.getElementById('left_input_icon');
let right_input_icon = document.getElementById('right_input_icon');


left_input.addEventListener('change', ()=> {
  let array_1000_50000 = all_shoes_array.filter((el) => {
    return el.Price <= 50000;
  })
  left_input_icon.style.left = left_input.value+'%';
  // console.log( left_input.value+'%')
  let price_box_value_left = (50000 / 100)* left_input.value;
  document.getElementById('left_input_price').innerText = (price_box_value_left);
  // console.log(price_box_value_left);
  let array_1000_50000_left = array_1000_50000.filter((el) => {
    return el.Price >= price_box_value_left;
  })
  // console.log(array_1000_50000_left);

  main_shoes_bx.innerHTML = '';
  array_1000_50000_left.forEach((el, i) => {
    const {Img,Name,Category, MRP, Price,Tag, Color} = el;
    let card = document.createElement('a');
    card.classList.add('card');
    card.innerHTML = `
    <img src="${Img}" alt="${Name}" />
    <h5 class="card_title" title="${Name}">
    ${Name}
    </h5>
    <p>${Category} Shoes</p>
    <div class="price">
      <h5>Rs ${Price}</h5>
      <h5>MRP: <del>RS ${MRP}</del></h5>
    </div>
    <div class="color_tag">
      <h6>Color ${Color}</h6>
      <h6>${Tag}</h6>
    </div>
    `;
main_shoes_bx.appendChild(card)
});
})

// right 

right_input.addEventListener('change', ()=> {
  right_input_icon.style.left = right_input.value+'%';
  // console.log( left_input.value+'%')
  let price_box_value_right = (50000 / 100)* right_input.value;
  // console.log(price_box_value_left);
  document.getElementById('right_input_price').innerText = (price_box_value_right + 50000);
  let array_50001_100000 = all_shoes_array.filter((el) => {
    return el.Price >= 50000;
  })
  let array_1000_50000_right = array_50001_100000.filter((el) => {
    return el.Price >= (price_box_value_right+50000);
  })
  // console.log(array_1000_50000_left);

  main_shoes_bx.innerHTML = '';
  array_1000_50000_right.forEach((el, i) => {
    const {Img,Name,Category, MRP, Price,Tag, Color} = el;
    let card = document.createElement('a');
    card.classList.add('card');
    card.innerHTML = `
    <img src="${Img}" alt="${Name}" />
    <h5 class="card_title" title="${Name}">
    ${Name}
    </h5>
    <p>${Category} Shoes</p>
    <div class="price">
      <h5>Rs ${Price}</h5>
      <h5>MRP: <del>RS ${MRP}</del></h5>
    </div>
    <div class="color_tag">
      <h6>Color ${Color}</h6>
      <h6>${Tag}</h6>
    </div>
    `;
main_shoes_bx.appendChild(card)
});
})

const color = ['white', 'gray-white', 'yellow', 'yellow-black', 'orange', 'green',
'sky-blue', 'pink', 'red', 'blue', 'gray-black', 'brown', 'black'];

Array.from(document.getElementsByClassName('color')).forEach((el, i) => {
  el.addEventListener('click', ()=> {
    const color_array = all_shoes_array.filter((el)=> {
      return el.ColorTag === color[i];
    });
    main_shoes_bx.innerHTML = '';
    color_array.forEach((el, i) => {
      const {Img,Name,Category, MRP, Price,Tag, Color} = el;
      let card = document.createElement('a');
      card.classList.add('card');
      card.innerHTML = `
      <img src="${Img}" alt="${Name}" />
      <h5 class="card_title" title="${Name}">
      ${Name}
      </h5>
      <p>${Category} Shoes</p>
      <div class="price">
        <h5>Rs ${Price}</h5>
        <h5>MRP: <del>RS ${MRP}</del></h5>
      </div>
      <div class="color_tag">
        <h6>Color ${Color}</h6>
        <h6>${Tag}</h6>
      </div>
      `;
  main_shoes_bx.appendChild(card)
  });
  })
})



document.getElementsByClassName('colors')[0].addEventListener('click', ()=> {
  main_shoes_bx.innerHTML = '';
  all_shoes_array.forEach((el, i) => {
    const {Img,Name,Category, MRP, Price,Tag, Color} = el;
    let card = document.createElement('a');
    card.classList.add('card');
    card.innerHTML = `
    <img src="${Img}" alt="${Name}" />
    <h5 class="card_title" title="${Name}">
    ${Name}
    </h5>
    <p>${Category} Shoes</p>
    <div class="price">
      <h5>Rs ${Price}</h5>
      <h5>MRP: <del>RS ${MRP}</del></h5>
    </div>
    <div class="color_tag">
      <h6>Color ${Color}</h6>
      <h6>${Tag}</h6>
    </div>
    `;
main_shoes_bx.appendChild(card)
});
})
// size 
 const number = [4,7,9,6,5,8,10,11.5,9.5,16,17,18,11,8.5];

 document.getElementsByClassName('size')[0].addEventListener('click', ()=> {
  main_shoes_bx.innerHTML = '';

  let number_array = all_shoes_array.filter((el) => {
    return el.Size4 === number[0];
  })

  number_array.forEach((el, i) => {
    const {Img,Name,Category, MRP, Price,Tag, Color} = el;
    let card = document.createElement('a');
    card.classList.add('card');
    card.innerHTML = `
    <img src="${Img}" alt="${Name}" />
    <h5 class="card_title" title="${Name}">
    ${Name}
    </h5>
    <p>${Category} Shoes</p>
    <div class="price">
      <h5>Rs ${Price}</h5>
      <h5>MRP: <del>RS ${MRP}</del></h5>
    </div>
    <div class="color_tag">
      <h6>Color ${Color}</h6>
      <h6>${Tag}</h6>
    </div>
    `;
  main_shoes_bx.appendChild(card)
});
 })


 document.getElementsByClassName('size')[1].addEventListener('click', ()=> {
  main_shoes_bx.innerHTML = '';

  let number_array = all_shoes_array.filter((el) => {
    return el.Size7 === number[1];
  })

  number_array.forEach((el, i) => {
    const {Img,Name,Category, MRP, Price,Tag, Color} = el;
    let card = document.createElement('a');
    card.classList.add('card');
    card.innerHTML = `
    <img src="${Img}" alt="${Name}" />
    <h5 class="card_title" title="${Name}">
    ${Name}
    </h5>
    <p>${Category} Shoes</p>
    <div class="price">
      <h5>Rs ${Price}</h5>
      <h5>MRP: <del>RS ${MRP}</del></h5>
    </div>
    <div class="color_tag">
      <h6>Color ${Color}</h6>
      <h6>${Tag}</h6>
    </div>
    `;
  main_shoes_bx.appendChild(card)
});
 })


